import { useState, useEffect } from 'react';
import { 
  FolderOpen,
  Image,
  Leaf,
  Zap,
  RefreshCw,
  Plus,
  Edit2,
  Trash2,
  X,
  Save
} from 'lucide-react';

const MATERIAL_COLORS = {
  bricks: '#ef4444',
  concrete: '#6b7280',
  aggregate: '#a78bfa',
  aerated_block: '#60a5fa',
  concrete_block: '#9ca3af',
  limestone_block: '#fbbf24',
  rammed_earth: '#78350f',
  timber: '#84cc16',
  steel: '#475569',
  glass: '#06b6d4',
  aluminum: '#64748b',
  insulation_mineral_wool: '#f472b6',
  insulation_cellulose: '#22c55e',
  plasterboard: '#e2e8f0',
  ceramic_tiles: '#fb923c'
};

function Classes() {
  const [classes, setClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [classSamples, setClassSamples] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [editingClass, setEditingClass] = useState(null);
  const [formData, setFormData] = useState({
    key: '',
    name: '',
    description: '',
    embodiedEnergy: '',
    embodiedCarbon: '',
    density: '',
    alternatives: ''
  });

  useEffect(() => {
    fetchClasses();
  }, []);

  const fetchClasses = async () => {
    try {
      const response = await fetch('/api/classes');
      const data = await response.json();
      setClasses(data);
      
      data.forEach(cls => {
        fetchClassSamples(cls.id);
      });
    } catch (error) {
      console.error('Error fetching classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchClassSamples = async (classId) => {
    try {
      const response = await fetch(`/api/classes/${classId}/samples`);
      const samples = await response.json();
      setClassSamples(prev => ({ ...prev, [classId]: samples.slice(0, 4) }));
    } catch (error) {
      console.error('Error fetching samples:', error);
    }
  };

  const getMaterialColor = (classId) => {
    return MATERIAL_COLORS[classId] || '#3b82f6';
  };

  const openAddModal = () => {
    setEditingClass(null);
    setFormData({
      key: '',
      name: '',
      description: '',
      embodiedEnergy: '',
      embodiedCarbon: '',
      density: '',
      alternatives: ''
    });
    setShowModal(true);
  };

  const openEditModal = (cls) => {
    setEditingClass(cls);
    setFormData({
      key: cls.id,
      name: cls.name,
      description: cls.description || '',
      embodiedEnergy: cls.embodiedEnergy || '',
      embodiedCarbon: cls.embodiedCarbon || '',
      density: cls.density || '',
      alternatives: cls.alternatives?.join(', ') || ''
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const payload = {
      key: formData.key,
      name: formData.name,
      description: formData.description,
      embodiedEnergy: parseFloat(formData.embodiedEnergy) || 0,
      embodiedCarbon: parseFloat(formData.embodiedCarbon) || 0,
      density: parseFloat(formData.density) || 0,
      alternatives: formData.alternatives.split(',').map(s => s.trim()).filter(Boolean)
    };

    try {
      const url = editingClass 
        ? `/api/classes/${editingClass.id}`
        : '/api/classes';
      
      const response = await fetch(url, {
        method: editingClass ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        setShowModal(false);
        fetchClasses();
      } else {
        const error = await response.json();
        alert(error.error || 'Failed to save class');
      }
    } catch (error) {
      console.error('Error saving class:', error);
      alert('Failed to save class');
    }
  };

  const deleteClass = async (classId) => {
    if (!confirm('Are you sure you want to delete this custom class? All associated images will also be deleted.')) return;

    try {
      const response = await fetch(`/api/classes/${classId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchClasses();
      } else {
        const error = await response.json();
        alert(error.error || 'Failed to delete class');
      }
    } catch (error) {
      console.error('Error deleting class:', error);
    }
  };

  const iceClasses = classes.filter(c => !c.isCustom);
  const customClasses = classes.filter(c => c.isCustom);

  return (
    <div>
      <div className="page-header">
        <div className="flex justify-between items-center">
          <div>
            <h2>Material Classes</h2>
            <p>ICE database materials and custom classes for carbon footprint analysis</p>
          </div>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button className="btn btn-primary" onClick={openAddModal}>
              <Plus size={16} />
              Add Custom Class
            </button>
            <button className="btn btn-outline" onClick={fetchClasses}>
              <RefreshCw size={16} />
              Refresh
            </button>
          </div>
        </div>
      </div>

      <div className="card" style={{ marginBottom: '24px', background: 'linear-gradient(135deg, #1e3a5f 0%, #1e293b 100%)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ 
            width: '60px', 
            height: '60px', 
            borderRadius: '12px', 
            background: 'rgba(16, 185, 129, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Leaf size={28} color="#10b981" />
          </div>
          <div>
            <h3 style={{ color: 'var(--text-primary)', marginBottom: '4px' }}>ICE Database Materials</h3>
            <p className="text-muted">
              Aligned with the Inventory of Carbon and Energy (ICE) database for accurate embodied carbon calculations.
              Add custom material classes to extend the training dataset.
            </p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="card">
          <div className="empty-state">
            <RefreshCw size={48} className="spinning" />
            <h3>Loading materials...</h3>
          </div>
        </div>
      ) : (
        <>
          <h3 style={{ color: 'var(--text-primary)', marginBottom: '16px' }}>
            ICE Database Materials ({iceClasses.length})
          </h3>
          <div className="classes-grid" style={{ marginBottom: '32px' }}>
            {iceClasses.map(cls => {
              const color = getMaterialColor(cls.id);
              
              return (
                <div 
                  key={cls.id}
                  className="class-card"
                  style={{ borderLeft: `4px solid ${color}` }}
                >
                  <div className="class-card-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{
                        width: '12px',
                        height: '12px',
                        borderRadius: '50%',
                        background: color
                      }} />
                      <span className="class-card-name" style={{ fontSize: '14px' }}>
                        {cls.name}
                      </span>
                    </div>
                    <span className="class-card-count">{cls.sampleCount} images</span>
                  </div>
                  
                  {cls.description && (
                    <p className="class-card-description" style={{ fontSize: '13px' }}>
                      {cls.description}
                    </p>
                  )}
                  
                  <div style={{ 
                    display: 'flex', 
                    gap: '16px', 
                    marginTop: '12px', 
                    padding: '12px',
                    background: 'var(--bg-primary)',
                    borderRadius: '8px'
                  }}>
                    <div style={{ textAlign: 'center', flex: 1 }}>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>
                        <Zap size={12} style={{ display: 'inline', marginRight: '4px' }} />
                        Energy
                      </div>
                      <div style={{ fontSize: '14px', color: '#f97316', fontWeight: '600' }}>
                        {cls.embodiedEnergy || 'N/A'} MJ/kg
                      </div>
                    </div>
                    <div style={{ textAlign: 'center', flex: 1 }}>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>
                        <Leaf size={12} style={{ display: 'inline', marginRight: '4px' }} />
                        Carbon
                      </div>
                      <div style={{ fontSize: '14px', color: '#10b981', fontWeight: '600' }}>
                        {cls.embodiedCarbon || 'N/A'} kgCO₂/kg
                      </div>
                    </div>
                  </div>

                  {cls.alternatives?.length > 0 && (
                    <div style={{ marginTop: '12px' }}>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '6px' }}>
                        Lower carbon alternatives:
                      </div>
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        {cls.alternatives.map(alt => (
                          <span key={alt} className="badge badge-info" style={{ fontSize: '10px' }}>
                            {alt.replace(/_/g, ' ')}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="class-card-preview" style={{ marginTop: '12px' }}>
                    {classSamples[cls.id]?.length > 0 ? (
                      classSamples[cls.id].map(sample => (
                        <img 
                          key={sample.id}
                          src={sample.thumbnailUrl || sample.url}
                          alt={sample.filename}
                          style={{ width: '48px', height: '48px', borderRadius: '6px', objectFit: 'cover' }}
                        />
                      ))
                    ) : (
                      <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: '8px',
                        color: 'var(--text-muted)',
                        fontSize: '13px',
                        padding: '8px 0'
                      }}>
                        <Image size={16} />
                        No training images yet
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {customClasses.length > 0 && (
            <>
              <h3 style={{ color: 'var(--text-primary)', marginBottom: '16px' }}>
                Custom Classes ({customClasses.length})
              </h3>
              <div className="classes-grid">
                {customClasses.map(cls => {
                  const color = getMaterialColor(cls.id) || '#8b5cf6';
                  
                  return (
                    <div 
                      key={cls.id}
                      className="class-card"
                      style={{ borderLeft: `4px solid ${color}` }}
                    >
                      <div className="class-card-header">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            background: color
                          }} />
                          <span className="class-card-name" style={{ fontSize: '14px' }}>
                            {cls.name}
                          </span>
                          <span className="badge badge-info" style={{ fontSize: '10px' }}>Custom</span>
                        </div>
                        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                          <span className="class-card-count">{cls.sampleCount} images</span>
                          <button 
                            className="btn btn-outline btn-sm" 
                            onClick={() => openEditModal(cls)}
                            style={{ padding: '4px 8px' }}
                          >
                            <Edit2 size={12} />
                          </button>
                          <button 
                            className="btn btn-danger btn-sm" 
                            onClick={() => deleteClass(cls.id)}
                            style={{ padding: '4px 8px' }}
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                      
                      {cls.description && (
                        <p className="class-card-description" style={{ fontSize: '13px' }}>
                          {cls.description}
                        </p>
                      )}
                      
                      <div style={{ 
                        display: 'flex', 
                        gap: '16px', 
                        marginTop: '12px', 
                        padding: '12px',
                        background: 'var(--bg-primary)',
                        borderRadius: '8px'
                      }}>
                        <div style={{ textAlign: 'center', flex: 1 }}>
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>Energy</div>
                          <div style={{ fontSize: '14px', color: '#f97316', fontWeight: '600' }}>
                            {cls.embodiedEnergy || 'N/A'} MJ/kg
                          </div>
                        </div>
                        <div style={{ textAlign: 'center', flex: 1 }}>
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>Carbon</div>
                          <div style={{ fontSize: '14px', color: '#10b981', fontWeight: '600' }}>
                            {cls.embodiedCarbon || 'N/A'} kgCO₂/kg
                          </div>
                        </div>
                      </div>
                      
                      <div className="class-card-preview" style={{ marginTop: '12px' }}>
                        {classSamples[cls.id]?.length > 0 ? (
                          classSamples[cls.id].map(sample => (
                            <img 
                              key={sample.id}
                              src={sample.thumbnailUrl || sample.url}
                              alt={sample.filename}
                              style={{ width: '48px', height: '48px', borderRadius: '6px', objectFit: 'cover' }}
                            />
                          ))
                        ) : (
                          <div style={{ 
                            display: 'flex', 
                            alignItems: 'center', 
                            gap: '8px',
                            color: 'var(--text-muted)',
                            fontSize: '13px',
                            padding: '8px 0'
                          }}>
                            <Image size={16} />
                            No training images yet
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '500px' }}>
            <div className="modal-header">
              <h3 className="modal-title">
                {editingClass ? 'Edit Custom Class' : 'Add Custom Class'}
              </h3>
              <button className="modal-close" onClick={() => setShowModal(false)}>
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Key (unique identifier)</label>
                <input 
                  className="input"
                  value={formData.key}
                  onChange={e => setFormData({ ...formData, key: e.target.value })}
                  placeholder="e.g., recycled_concrete"
                  disabled={!!editingClass}
                  required
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Name</label>
                <input 
                  className="input"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Recycled Concrete"
                  required
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Description</label>
                <input 
                  className="input"
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of the material"
                />
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div className="form-group">
                  <label className="form-label">Embodied Energy (MJ/kg)</label>
                  <input 
                    className="input"
                    type="number"
                    step="0.01"
                    value={formData.embodiedEnergy}
                    onChange={e => setFormData({ ...formData, embodiedEnergy: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                
                <div className="form-group">
                  <label className="form-label">Embodied Carbon (kgCO₂/kg)</label>
                  <input 
                    className="input"
                    type="number"
                    step="0.001"
                    value={formData.embodiedCarbon}
                    onChange={e => setFormData({ ...formData, embodiedCarbon: e.target.value })}
                    placeholder="0.000"
                  />
                </div>
              </div>
              
              <div className="form-group">
                <label className="form-label">Density (kg/m³)</label>
                <input 
                  className="input"
                  type="number"
                  value={formData.density}
                  onChange={e => setFormData({ ...formData, density: e.target.value })}
                  placeholder="0"
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Alternatives (comma-separated keys)</label>
                <input 
                  className="input"
                  value={formData.alternatives}
                  onChange={e => setFormData({ ...formData, alternatives: e.target.value })}
                  placeholder="e.g., concrete, limestone_block"
                />
              </div>
              
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <Save size={16} />
                  {editingClass ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Classes;
